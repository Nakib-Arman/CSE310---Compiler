#!usr/bin/bash

flex main.l
g++ 